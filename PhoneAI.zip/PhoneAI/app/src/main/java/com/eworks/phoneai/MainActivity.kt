package com.eworks.phoneai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.*

class MainActivity : Activity() {
    private lateinit var list: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 64, 32, 32) }
        val key = EditText(this).apply { hint = "Anthropic API key"; setText(p.getString("key", "")) }
        val tone = EditText(this).apply { hint = "Reply style"; setText(p.getString("tone", "Friendly, brief, professional. Australian English.")) }
        val auto = CheckBox(this).apply { text = "Auto-send replies (use with care)"; isChecked = p.getBoolean("auto", false) }
        val save = Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                p.edit().putString("key", key.text.toString().trim()).putString("tone", tone.text.toString())
                    .putBoolean("auto", auto.isChecked).apply()
                Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
            }
        }
        val access = Button(this).apply {
            text = "1. Enable notification access"
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(access, key, tone, auto, save, list).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); Store.onChange = { render() }; render() }
    override fun onPause() { super.onPause(); Store.onChange = null }

    private fun render() {
        list.removeAllViews()
        val copy = synchronized(Store.msgs) { Store.msgs.toList() }
        for (m in copy) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 32, 0, 16) }
            card.addView(TextView(this).apply { text = "${m.app} - ${m.title}\n${m.text}\n[${m.status}]"; textSize = 15f })
            val ed = EditText(this).apply {
                setText(m.draft); hint = "Draft reply"
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(e: Editable?) { m.draft = e.toString() }
                    override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                    override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                })
            }
            card.addView(ed)
            val row = LinearLayout(this)
            fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
            row.addView(btn("Send") { Store.send(this, m) })
            row.addView(btn("Redraft") { Ai.draft(this, m) })
            row.addView(btn("Dismiss") { synchronized(Store.msgs) { Store.msgs.remove(m) }; render() })
            card.addView(row)
            list.addView(card)
        }
    }
}
