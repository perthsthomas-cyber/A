package com.eworks.phoneai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val act = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val app = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }
                  catch (e: Exception) { sbn.packageName }
        val m = Msg(sbn.key, app, title, text, act)
        synchronized(Store.msgs) {
            if (Store.msgs.any { it.key == sbn.key && it.text == text }) return
            Store.msgs.removeAll { it.key == sbn.key }
            Store.msgs.add(0, m)
            while (Store.msgs.size > 50) Store.msgs.removeAt(Store.msgs.size - 1)
        }
        Store.changed()
        val auto = getSharedPreferences("p", 0).getBoolean("auto", false)
        Ai.draft(this, m) { if (auto) Store.send(this, m) }
    }
}
