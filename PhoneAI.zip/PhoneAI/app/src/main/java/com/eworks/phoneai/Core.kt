package com.eworks.phoneai

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Msg(val key: String, val app: String, val title: String, val text: String,
          val action: Notification.Action?, var draft: String = "", var status: String = "Drafting...")

object Store {
    val msgs = mutableListOf<Msg>()
    var onChange: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    fun changed() { main.post { onChange?.invoke() } }

    fun send(ctx: Context, m: Msg) {
        val a = m.action ?: return
        val ris = a.remoteInputs ?: return
        if (ris.isEmpty() || m.draft.isBlank()) return
        val i = Intent(); val b = Bundle()
        b.putCharSequence(ris[0].resultKey, m.draft)
        RemoteInput.addResultsToIntent(ris, i, b)
        m.status = try { a.actionIntent.send(ctx, 0, i); "Sent" } catch (e: Exception) { "Send failed (reply expired)" }
        changed()
    }
}

object Ai {
    fun draft(ctx: Context, m: Msg, done: () -> Unit = {}) {
        Thread {
            val p = ctx.getSharedPreferences("p", 0)
            val key = p.getString("key", "") ?: ""
            if (key.isBlank()) { m.status = "Add your API key"; Store.changed(); return@Thread }
            m.status = "Drafting..."; Store.changed()
            try {
                val body = JSONObject()
                    .put("model", "claude-haiku-4-5-20251001").put("max_tokens", 300)
                    .put("system", "You write replies to phone messages on behalf of the phone's owner. Style: " +
                        p.getString("tone", "") + ". Reply with only the message text, nothing else.")
                    .put("messages", JSONArray().put(JSONObject().put("role", "user")
                        .put("content", "App: ${m.app}\nFrom: ${m.title}\nMessage: ${m.text}")))
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                val s = (if (c.responseCode < 300) c.inputStream else c.errorStream).bufferedReader().readText()
                if (c.responseCode >= 300) throw Exception(s.take(120))
                m.draft = JSONObject(s).getJSONArray("content").getJSONObject(0).getString("text").trim()
                m.status = "Draft ready"
            } catch (e: Exception) { m.status = "Error: ${e.message}" }
            Store.changed(); done()
        }.start()
    }
}
