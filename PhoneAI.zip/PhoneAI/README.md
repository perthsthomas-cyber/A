# Phone AI
1. Create a new GitHub repo, upload all these files (keep the .github folder), commit.
2. Repo > Actions > "Build APK" > wait for green tick > download the PhoneAI-apk artifact (unzip for app-debug.apk).
3. Install the APK on your Android (allow "install unknown apps").
4. Open Phone AI > Enable notification access > turn it on for Phone AI.
5. Paste your Anthropic API key, set your reply style, Save.
Incoming messages with a quick-reply button (SMS, WhatsApp, Messenger, etc.) appear with an AI draft. Edit, then Send.
